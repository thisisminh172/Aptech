﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_test
{
    public abstract class Library
    {
        public abstract void bookInfo();
    }
}
