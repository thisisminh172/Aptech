
package sale;


public interface IDiscount {
    public void displayDetails();
}
